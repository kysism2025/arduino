

#ifndef __My_key_LIB__
#define __My_key_LIB__

#define UP_key   14
#define DN_key   15
#define RUN_key  16
#define STOP_key 17
#define MODE_key 18
#define EXT_key  19

#define d_in(pin) digitalRead(pin)

#endif
